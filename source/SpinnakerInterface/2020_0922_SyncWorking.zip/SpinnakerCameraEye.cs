﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenIris;
using OpenIris.ImageGrabbing;

using SpinnakerNET;
using SpinnakerNET.GenApi;

namespace SpinnakerInterface
{
    class SpinnakerCameraEye : CameraEye
    {
        // Static members, to keep track of all cameras.
        public static List<SpinnakerCameraEye> CAMLIST = new List<SpinnakerCameraEye>();
        public static int NCAMS => CAMLIST.Count();

        // One "MASTER" camera is chosen "arbitrarily" to generate hardware triggers for
        // all cameras.
        public static SpinnakerCameraEye MASTERCAM = null;

        public static List<SpinnakerCameraEye> EnumerateCameras()
        {
            // Retrieve singleton reference to Spinnaker system object
            ManagedSystem system = new ManagedSystem();

            // Get current library version
            // version = self.system.GetLibraryVersion()
            // print('FLIR Spinnaker Library version: %d.%d.%d.%d' % (version.major, version.minor, version.type, version.build))

            // Retrieve list of cameras from the system
            var cam_list = system.GetCameras();

            if (cam_list.Count < 2)
            {
                throw new Exception($"NEED TWO CAMERAS!! Found {cam_list.Count} FLIR Spinnaker compatible camera(s).");
            }

            Trace.WriteLine($"Found {cam_list.Count} cameras. Calling cam.Init()...");
            CAMLIST.Add(new SpinnakerCameraEye(cam_list[0], Eye.Left));
            CAMLIST.Add(new SpinnakerCameraEye(cam_list[1], Eye.Right));

            // Pick one of the cameras (MUST be a Blackfly) to be the MASTER.
            MASTERCAM = null;
            foreach (var CAM in CAMLIST)
                if (CAM.cam.DeviceModelName.Value.Contains("Blackfly"))
                {
                    MASTERCAM = CAM;
                    break;
                }

            return CAMLIST;
        }

        public static void EndSynchronizedAcquisition()
        {
            if (MASTERCAM == null) return;
            MASTERCAM.EnableMasterTriggers(false);   // Stop the triggers.
            Thread.Sleep(50);
            foreach (var CAM in CAMLIST)
                try { CAM.cam.EndAcquisition(); } catch { }
        }

        public static void BeginSynchronizedAcquisition()
        {
            EndSynchronizedAcquisition();  // Make sure everyone is stopped.

            CAMLIST[0].Start();
            CAMLIST[1].Start();
            MASTERCAM.SetMaster();
            MASTERCAM.cam.BeginAcquisition();
            MASTERCAM.EnableMasterTriggers(true);

            //foreach (var CAM in CAMLIST) CAM.AutoExposureOnce();
        }

        // =========================================================================================
        // Below here are all instance members.

        int Count = 0;

        IManagedCamera cam;
        long frameCounter;
        string CamModelName = "";

        ulong CurrentFrameCounter;
        ulong FirstFrameID, CurrentFrameID;

        // If this Info property is implemented, then it is evaluated periodically by the GUI, and
        // the string it returns is displayed on the Timing tab, if Debug is enabled.
        //
        // Handy for showing a continuously updated Debug string in the Timing tab. Can show things
        // like camera frame numbers, dropped frames, whatever. MUST enable Debug in the Settings in
        // order for the Debug and Timing tabs to show up in the user interface. Every camera gets
        // its own string, so we must distinguish which camera this pertains to.
        public override object Info =>
            $"This string shows up in Timing tab!! [{WhichEye}{(ISMASTER ? "[Master]" : "")}: {CamModelName}] (updated periodically {Count++})\n"
          + $"FrameCounter {CurrentFrameCounter}  FrameID {CurrentFrameID}\n\n";

        bool ISMASTER => this == MASTERCAM;

        public SpinnakerCameraEye(IManagedCamera CAM, Eye which)
        {
            this.cam = CAM;
            this.WhichEye = which;
            Init();
        }

        public void Init()
        {
            cam.Init();
            CamModelName = cam.DeviceModelName.Value;
        }

        public override void Start()
        {
            if (cam == null) return;

            //self.InitParameters()
            //self.InitROI()

            //FrameRate = cam.AcquisitionFrameRate;
            FrameRate = FRAME_RATE;

            //cam.AcquisitionFrameRate.Value = FrameRate;
            InitParameters();
            cam.BeginAcquisition();
        }

        public override void Stop()
        {
            cam.EndAcquisition();
        }

        const string TRIGGER_LINE = "Line2";
        const string STROBE_OUT_LINE = "Line1";
        const double FRAME_RATE = 499;
        const int FRAME_XSIZE = 400, FRAME_YSIZE = 300;

        public void EnableMasterTriggers(bool Enable)
        {
            if (this != MASTERCAM) return;

            if (Enable)
                // Allow internal camera triggering, so this camera generates frame triggers.
                cam.TriggerMode.FromString("Off");
            else
            {
                // Disable camera triggering.
                cam.TriggerSource.FromString("Software");
                cam.TriggerMode.FromString("On");
            }
        }

        void CenterROI()
        {
            var Xoff = (cam.WidthMax.Value - cam.Width.Value) / 2;
            var Yoff = (cam.HeightMax.Value - cam.Height.Value) / 2;
            cam.OffsetX.Value = Xoff;
            cam.OffsetY.Value = Yoff;
        }

        // Initialize camera parameters. This sets up the camera to be a "slave" of the
        // frame triggers. Later, we pick one camera to be the "master".
        public void InitParameters()
        {
            // Make sure camera is really stopped.
            cam.BeginAcquisition();
            cam.EndAcquisition();

            cam.GammaEnable.Value = false;

            // Image frame/format settings.
            cam.AcquisitionFrameRateEnable.Value = false;
            cam.BinningHorizontal.Value = 1;
            cam.BinningVertical.Value = 1;
            cam.OffsetX.Value = 0;
            cam.OffsetY.Value = 0;
            cam.Width.Value = FRAME_XSIZE;
            cam.Height.Value = FRAME_YSIZE;
            CenterROI();

            // Image Chunk data, saved with each video frame.
            cam.ChunkModeActive.Value = true;
            cam.ChunkSelector.FromString("FrameID");
            cam.ChunkEnable.Value = true;

            // This saves the status of all 4 GPIO digital lines.
            try
            {
                cam.ChunkSelector.FromString("ExposureEndLineStatusAll");
                cam.ChunkEnable.Value = true;
            }
            catch { }

            // USB 2.0 is limited to ~43M, so try that first.
            //cam.DeviceLinkThroughputLimit.SetValue(int(43e6));
            //try: cam.DeviceLinkThroughputLimit.SetValue(int(500e6));
            //except: pass


            //# Trigger Settings
            cam.LineSelector.FromString(TRIGGER_LINE);
            try { cam.V3_3Enable.Value = false; } catch { }
            cam.LineMode.FromString("Input");
            cam.LineInverter.Value = false;
            try { cam.LineInputFilterSelector.FromString("Deglitch"); } catch { }
            cam.TriggerSelector.FromString("FrameStart");
            cam.TriggerSource.FromString(TRIGGER_LINE);
            cam.TriggerActivation.FromString("RisingEdge");
            try { cam.TriggerOverlap.FromString("ReadOut"); } catch { }

            cam.TriggerMode.FromString("On");
            //cam.TriggerMode.FromString("Off");

            //# MUST make sure all non-master cameras set STROBE_OUT_LINE to high.
            cam.LineSelector.FromString(STROBE_OUT_LINE);
            cam.LineInverter.Value = false;

            //# For Firefly, set to Input. For Blacfly, this will be an error,
            //# since the line is hard-wired as an output.        
            try { cam.LineMode.FromString("Input"); } catch { }

            try
            {
                //# For Blackfly, make sure the output is HIGH, so that only
                //# the master is pulling the line low.
                cam.LineSource.FromString("UserOutput3");
                cam.UserOutputSelector.Value = 3;
                cam.UserOutputValue.Value = true;
            }
            catch { }

            //# Exposure settings.
            cam.AcquisitionMode.FromString("Continuous");
            cam.GainAuto.FromString("Off");
            cam.ExposureAuto.FromString("Off");

            //# Set to 500uSec less than frame interval.
            cam.AutoExposureExposureTimeUpperLimit.Value = 1e6 / FRAME_RATE - 500;
            //#cam.AutoExposureExposureTimeUpperLimit.SetValue(1e6/FRAME_RATE - 2000)

            cam.ExposureTime.Value = cam.AutoExposureExposureTimeUpperLimit.Value - 100;
        }

        public void AutoExposureOnce()
        {
            // Do one-time Auto Exposure setting (lasts a few seconds).
            cam.GainAuto.FromString("Once");
            cam.ExposureAuto.FromString("Once");
        }

        public void SetMaster(bool Enable = false)
        {
            cam.EndAcquisition();         // Make sure camera is not acquiring images.
            EnableMasterTriggers(false);  // And disable trigger until we are ready!

            cam.LineSelector.FromString(TRIGGER_LINE);
            cam.LineMode.FromString("Output");
            cam.LineSource.FromString("ExposureActive");

            cam.AcquisitionMode.FromString("Continuous");
            cam.AcquisitionFrameRateEnable.Value = true;
            cam.AcquisitionFrameRate.Value = FRAME_RATE;

            if (Enable)
                EnableMasterTriggers(true);
        }

        protected override ImageEye GrabImageFromCamera()
        {
            if (!cam.IsStreaming())
                return null;

            //
            // Retrieve next received image
            //
            // *** NOTES ***
            // Capturing an image houses images on the camera buffer. 
            // Trying to capture an image that does not exist will 
            // hang the camera.
            //
            // Using-statements help ensure that images are released.
            // If too many images remain unreleased, the buffer will
            // fill, causing the camera to hang. Images can also be
            // released manually by calling Release().
            // 

            // 2020/08/14 Dale - We need to use try/except here, because GetNextImage() will
            // throw an exception if it is called after (or during?) EndAcquisition().
            //
            //   https://docs.microsoft.com/en-us/dotnet/csharp/language-reference/keywords/using-statement
            //
            // We expand the "using" statement into the equivalent try/finally syntax, and add "except"
            // to catch the exception and return null.

            //using (IManagedImage rawImage = cam.GetNextImage())

            IManagedImage rawImage = null;
            try
            {
                rawImage = cam.GetNextImage();

                // Ensure image completion
                //
                // *** NOTES ***
                //
                // Images can easily be checked for completion. This should be done whenever a
                // complete image is expected or required. Alternatively, check image status for a
                // little more insight into what happened.
                //
                if (rawImage.IsIncomplete)
                {
                    Console.WriteLine("Image incomplete with image status {0}...", rawImage.ImageStatus);
                }
                else
                {
                    //
                    // Convert image to mono 8
                    //
                    // *** NOTES ***
                    // Images can be converted between pixel formats by using the appropriate
                    // enumeration value. Unlike the original image, the converted one does not need
                    // to be released as it does not affect the camera buffer.
                    using (IManagedImage convertedImage = rawImage.Convert(PixelFormatEnums.Mono8))
                    {
                        frameCounter++;

                        // Build the new timestamp
                        var timestamp = new ImageEyeTimestamp
                        {
                            FrameNumber = (ulong)frameCounter,
                            //FrameNumberRaw = rawImage.ID,
                            FrameNumberRaw = rawImage.FrameID,
                            Seconds = rawImage.TimeStamp / 1e9
                        };

                        // Subtract out the initial hardware frame number, so we always start at Hardware Frame 0.
                        if (FirstFrameID == 0)
                            FirstFrameID = timestamp.FrameNumberRaw;

                        CurrentFrameCounter = timestamp.FrameNumber;
                        CurrentFrameID = timestamp.FrameNumberRaw - FirstFrameID;

                        return new ImageEye(
                                 (int)rawImage.Width,
                                 (int)rawImage.Height,
                                 (int)rawImage.Stride,
                                 rawImage.DataPtr,
                                 timestamp)
                        {
                            WhichEye = WhichEye,
                            ImageSourceData = rawImage
                        };
                    }
                }

            }
            catch
            {
                return null;
            }
            finally
            {
                rawImage?.Dispose();
            }

            return null;
        }
    }
}
